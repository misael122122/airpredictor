class Sensor():
	def __init__(data):
		raise NotImplementedError
	
	def getData():
		raise NotImplementedError
