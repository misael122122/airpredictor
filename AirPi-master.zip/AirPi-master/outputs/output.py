class Output():
	def __init__(self,data):
		raise NotImplementedError
	
	def outputData(self,dataPoints):
		raise NotImplementedError
